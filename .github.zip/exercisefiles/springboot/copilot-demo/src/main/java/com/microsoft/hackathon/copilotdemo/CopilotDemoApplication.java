package com.microsoft.hackathon.copilotdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CopilotDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CopilotDemoApplication.class, args);
	}

}
