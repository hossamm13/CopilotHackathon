package com.microsoft.hackathon.quarkus;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class DemoResourceIT extends DemoResourceTest {
    // Execute the same tests but in packaged mode.
}
