# Build a Quarkus native image

## Build the native executable


## Build the docker image using the Dockerfile.native-micro


## Run the docker image


## Test the application



